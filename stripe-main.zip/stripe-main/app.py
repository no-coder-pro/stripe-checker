from flask import Flask, request, jsonify, send_file
import requests
import urllib.parse
from flask_cors import CORS
import os

app = Flask(__name__)
CORS(app)

@app.route('/')
def home():
    return send_file('index.html')

@app.route('/api/check', methods=['GET'])
def check_card():
    card = request.args.get('card')
    email = request.args.get('email')
    password = request.args.get('pass')

    if not card:
        return jsonify({'error': 'card query parameter is required.'}), 400

    try:
        base_url = "https://stripe.bbinl.site/api/stripe2"
        payload = {
            'auth': card
        }
        if email:
            payload['email'] = email
        if password:
            payload['pass'] = password
            
        proxy = request.args.get('proxy')
        if proxy:
            payload['proxy'] = proxy

            
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(base_url, params=payload, headers=headers)

        if response.status_code != 200:
            print(f"Upstream Error: {response.status_code}")
            print(f"Response: {response.text}")

        try:
            data = response.json()
        except ValueError:
            data = {'message': response.text}
            
        return jsonify(data), response.status_code

    except Exception as e:
        print(f"Exception: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(port=3000)

